import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

// Initialize Gemini client lazily
let aiClient: GoogleGenAI | null = null;
function getGeminiClient() {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      console.warn(
        "GEMINI_API_KEY env variable is not set. Using offline converter fallback.",
      );
      return null;
    }
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Predefined conversion templates for offline use or as standard examples
const AC_TEMPLATES = {
  basic: `-- Assetto Corsa Gamepad Assist - Simple Speed Sensitivity
function update(dt)
    -- car.speed is in m/s, convert to km/h
    local speedKmh = car.speed * 3.6
    local stickInput = gamepad.leftStickX
    
    -- Reduce steering lock as speed increases
    local maxAngle = 1.0 / (1.0 + speedKmh * 0.04)
    local targetSteer = stickInput * maxAngle
    
    -- Set target steering
    car.steer = targetSteer
end`,
  advanced: `-- AC-Advanced-Gamepad-Assist (by adam10603)
-- Core translation of Adam's CSP gamepad steering rate, dynamic self-centering, & slip limits.
local speed_sensitivity = 0.045
local exp_gamma = 1.6
local countersteer_mult = 0.90
local max_steer_speed = 10.0 -- rad/s max rate of steering movement
local self_center_strength = 0.65

local last_steering_output = 0

function update(dt)
    local speed_kmh = car.speed * 3.6
    local stick_x = gamepad.leftStickX
    local yaw_rate = car.yawRate
    local slip_angle = car.slipAngle or 0

    -- 1. Apply Gamma (Non-linear stick curve)
    local stick_sign = stick_x >= 0 and 1 or -1
    local soft_input = stick_sign * (math.abs(stick_x) ^ exp_gamma)

    -- 2. Speed lock sensitivity
    local limit_factor = 1.0 / (1.0 + speed_kmh * speed_sensitivity)
    local target_steer = soft_input * limit_factor

    -- 3. Dynamic Countersteer Assistance (Cures power-slides and spinouts)
    local counter_steer = 0
    if math.abs(slip_angle) > 0.07 then
        -- Opposite steering reaction based on slip and rotational velocity
        counter_steer = -slip_angle * countersteer_mult
    end

    local final_target = target_steer + counter_steer
    
    -- Keep within actuator boundaries
    final_target = math.max(-1.0, math.min(1.0, final_target))

    -- 4. Elastic Rate Limiter (Simulating realistic hand movement velocity)
    local steer_error = final_target - last_steering_output
    local steer_step = steer_error * math.min(1.0, dt * max_steer_speed)
    last_steering_output = last_steering_output + steer_step

    car.steer = last_steering_output
end`,
  understeer: `-- Assetto Corsa Gamepad Assist - Understeer Reduction Filter
function update(dt)
    local speedKmh = car.speed * 3.6
    local steerInput = gamepad.leftStickX
    
    -- If tires slip too much, reduce steering limit to regain traction
    local slipRatio = car.frontTiresSlipRatio or 0
    local assistCorrection = 1.0
    
    if slipRatio > 0.15 then
        -- Reduce steering input proportionally to reduce understeer
        assistCorrection = math.max(0.3, 1.0 - (slipRatio - 0.15) * 2.0)
    end
    
    local targetSteer = steerInput * assistCorrection
    car.steer = targetSteer
end`,
};

const BEAMNG_TEMPLATES = {
  basic: `-- BeamNG.drive Vehicle Gamepad Assist - Speed Sensitivity
-- Place inside visual/lua/vehicle/extensions/gamepadAssistBasic.lua or controller directory

local M = {}

-- Parameters
local speedKmhMult = 3.6
local sensitivity = 0.04

local function updateGFX(dt)
    -- In BeamNG, electrics.values.wheelspeed is in m/s
    local wheelspeed = electrics.values.wheelspeed or 0
    local speedKmh = wheelspeed * speedKmhMult
    
    -- Read gamepad analog input (-1 to 1) 
    local steerInput = input.state.steering or 0
    
    -- Reduce steering lock as speed increases
    local maxAngle = 1.0 / (1.0 + speedKmh * sensitivity)
    local targetSteering = steerInput * maxAngle
    
    -- Apply final steering back to BeamNG's vehicle rack
    input.event("steering", targetSteering)
end

M.updateGFX = updateGFX
return M`,
  advanced: `-- lua/vehicle/extensions/agaPhysics.lua
local M = {}

M.config = {
    speed_sensitivity = 0.05,
    exp_gamma = 1.6,
    countersteer = 0.85,
    max_steer_speed = 15.0,
    understeer_assist = 0.5
}

local current_steering = 0
local function updateGFX(dt)
    -- Vektör Matematiği ve Hız Hesaplama
    local vel = obj:getVelocity() -- Yönü ve büyüklüğü ile birlikte aracın hızı
    local dir = obj:getDirectionVector() -- Aracın burnunun baktığı vektör
    local dirUp = obj:getDirectionVectorUp() -- Aracın üst yönü
    
    -- Aracın sağına/soluna olan yön vektörü (Cross Product kullanarak hesaplanır, getDirectionVectorRight YOKTUR!)
    local dirRight = dir:cross(dirUp)
    
    -- İleri/Geri (vx) ve Yanal (vy) hızları Dot Product ile hesapla (m/s)
    local vx = vel:dot(dir)
    local vy = vel:dot(dirRight)

    local speed_kmh = math.abs(vx) * 3.6
    
    -- Ham direksiyon verisini al (BeamNG'de electrics.values.steering_input kullanılır)
    local raw_steer = electrics.values.steering_input or 0
    
    -- Gamma (Hassasiyet eğrisi)
    local stick_sign = raw_steer >= 0 and 1 or -1
    local soft_input = stick_sign * (math.abs(raw_steer) ^ M.config.exp_gamma)
    
    -- Speed Limit (Hıza duyarlı maksimum direksiyon açısını daralt)
    local limit_factor = 1.0 / (1.0 + speed_kmh * M.config.speed_sensitivity)
    local target = soft_input * limit_factor
    
    -- Slide Angle & Countersteer
    local slip_angle = 0
    if math.abs(vx) > 2.0 then
        slip_angle = math.atan2(vy, math.abs(vx))
    end
    
    if math.abs(slip_angle) > 0.05 then
        target = target + (slip_angle * M.config.countersteer)
    end
    
    -- Understeer Assist (Önden Kayma Kurtarıcısı)
    local understeer_correction = 1.0
    -- Eğer hız yüksekse, oyuncu direksiyonu çok çeviriyorsa ama araç kaymıyorsa (kafadan açarak gidiyorsa)
    if speed_kmh > 40 and math.abs(raw_steer) > 0.4 and math.abs(slip_angle) < 0.1 then
        understeer_correction = math.max(0.3, 1.0 - M.config.understeer_assist)
    end
    target = target * understeer_correction
    
    -- Sınırlayıcı ve Uygulayıcı (Zamanla yumuşatma)
    target = math.max(-1.0, math.min(1.0, target))
    local steer_error = target - current_steering
    current_steering = current_steering + steer_error * math.min(1.0, dt * M.config.max_steer_speed)
    
    -- İşlenmiş asistanlı direksiyon çıktısını doğrudan hidroliklere bas. (input.event araç içinde çalışmaz)
    electrics.values.steering = current_steering
end

local function setConfig(cfg)
    if cfg.speed_sensitivity then M.config.speed_sensitivity = cfg.speed_sensitivity end
    if cfg.countersteer then M.config.countersteer = cfg.countersteer end
    if cfg.max_steer_speed then M.config.max_steer_speed = cfg.max_steer_speed end
    if cfg.understeer_assist then M.config.understeer_assist = cfg.understeer_assist end
    if cfg.exp_gamma then M.config.exp_gamma = cfg.exp_gamma end
end

M.updateGFX = updateGFX
M.setConfig = setConfig
return M`,
  understeer: `-- BeamNG.drive Vehicle Gamepad Assist - Understeer Regain Filter
-- Place file inside: /lua/vehicle/extensions/gamepadAssistUndersteer.lua

local M = {}

local function updateGFX(dt)
    local steerInput = input.state.steering or 0
    
    -- Retrieve aggregate wheel slip in BeamNG.drive
    -- Using BeamNG wheel speed differences to estimate front/rear slip
    local wheelSpeed = electrics.values.wheelspeed or 0
    local airspeed = electrics.values.airspeed or 0
    
    local slipRatio = 0
    if airspeed > 2.0 then
        slipRatio = math.abs(wheelSpeed - airspeed) / airspeed
    end
    
    local assistCorrection = 1.0
    if slipRatio > 0.15 then
        -- Reduce steering input proportionally to reduce front wheels scrub
        assistCorrection = math.max(0.3, 1.0 - (slipRatio - 0.15) * 2.0)
    end
    
    local targetSteer = steerInput * assistCorrection
    
    input.event("steering", targetSteer)
end

M.updateGFX = updateGFX
return M`,
};

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware
  app.use(express.json());

  // Static files or Vite integration
  app.get("/api/templates", (req, res) => {
    res.json({
      ac: AC_TEMPLATES,
      beamng: BEAMNG_TEMPLATES,
    });
  });

  // Code Translation endpoint
  app.post("/api/translate", async (req, res) => {
    const { code, style = "advanced", customPrompt = "" } = req.body;

    if (!code) {
      return res
        .status(400)
        .json({ error: "No Assetto Corsa Lua code provided." });
    }

    const ai = getGeminiClient();

    if (!ai) {
      // Offline fallback
      console.log(
        "Using local offline approximation conversion based on style:",
        style,
      );
      let fallbackCode = BEAMNG_TEMPLATES.advanced;
      if (style === "basic") fallbackCode = BEAMNG_TEMPLATES.basic;
      if (style === "understeer") fallbackCode = BEAMNG_TEMPLATES.understeer;

      return res.json({
        translatedCode: fallbackCode,
        explanation:
          "Converted using high-fidelity offline mapping blueprints because GEMINI_API_KEY is not defined. Full BeamNG.drive vehicle input framework structured successfully.",
        isOfflineFallback: true,
      });
    }

    try {
      const prompt = `You are an expert game developer specializing in Assetto Corsa lua scripts, CSP physics, and BeamNG.drive vehicle Lua modding API.
Task: Translate the following Assetto Corsa gamepad assist Lua code/algorithms to a fully functioning, syntactically correct BeamNG.drive Vehicle Engine Lua Extension code.

Assetto Corsa Lua Code:
\`\`\`lua
${code}
\`\`\`

Custom Instructions and preferences:
${customPrompt}

BeamNG API and vehicle state details:
- BeamNG vehicle scripts generally run in the Vehicle Lua VM.
- All code should be written as an extension module that returns a table (e.g. \`local M = {}\` and \`return M\`).
- Use the main driver function \`updateGFX(dt)\` which runs on every physics frame update.
- Input: read direct analog input using \`input.state.steering\` (or digital keys if necessary, but keep layout smooth).
- Output: apply the calculated steering output using \`input.event("steering", steeringValue)\`, where steeringValue is in range [-1.0, 1.0].
- Vehicles, wheels, and sensors can be read via:
  - \`electrics.values.wheelspeed\` (speed in m/s)
  - \`sensors.yawRate\` (yaw rate in rad/s)
  - \`sensors.gx\` (lateral accelerometers/G-forces)
  - \`electrics.values.vx\` (longitudinal forward speed in m/s)
  - \`electrics.values.vy\` (lateral speed in m/s)
- Keep physical properties correctly calibrated (convert km/h, raw angles, use robust limits).
- Structure the resulting Lua script beautifully with comments explaining parameters.
- Provide a brief, professional description of the core changes made, highlighting the difference between AC's telemetry state and BeamNG's \`electrics\` and \`sensors\` tables.

Provide your output in valid JSON format matching this schema:
{
  "translatedCode": "string (the complete, fully annotated and runnable BeamNG vehicle Lua script)",
  "explanation": "string (brief overview of physics conversion, parameter maps, and help instructions on where to save the files)"
}
Response MUST be valid raw JSON. Only output the JSON structure without any additional markdown wrappers outside of it.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
        },
      });

      const responseText = response.text || "{}";
      const resultObj = JSON.parse(responseText.trim());

      res.json({
        translatedCode: resultObj.translatedCode || BEAMNG_TEMPLATES.advanced,
        explanation: resultObj.explanation || "Converted successfully.",
        isOfflineFallback: false,
      });
    } catch (error: any) {
      console.error("Gemini Translation Error:", error);
      res.status(500).json({
        error: "Translation failed",
        details: error.message,
        translatedCode: BEAMNG_TEMPLATES.advanced,
        explanation:
          "A translation error occurred. Showing the advanced BeamNG gamepad assist outline as reference.",
      });
    }
  });

  // Client-Side static hosting vs Vite middleware
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server is booted and listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();

export type TemplateType = "basic" | "advanced" | "understeer";

export interface AssistConfig {
  speedSensitivity: number; // Sensitivity factor
  counterSteerStrength: number; // Lateral yaw counter action multiplier
  smoothingRate: number; // Filter rates
  understeerRegain: number; // Slip protection limit
  deadzone: number; // Analog stick deadzone
}

export interface SimState {
  playerSteerInput: number; // Range [-1.0, 1.0]
  calculatedSteerOutput: number; // Range [-1.0, 1.0]
  speedKmh: number; // Virtual speed
  yawRate: number; // Rad/s rotation
  slipAngle: number; // Drift angle in radians
  isDrifting: boolean;
  isUndersteering: boolean;
  currentGForce: number; // Lateral acceleration
}

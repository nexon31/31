import React, { useState, useEffect } from "react";
import { TemplateType, AssistConfig, SimState } from "./types";
import JSZip from "jszip";
import { saveAs } from "file-saver";
import { Download, AlertCircle, FileArchive, CheckCircle2 } from "lucide-react";

// Default configuration presets for the sandbox simulator
const DEFAULT_CONFIGS: Record<TemplateType, AssistConfig> = {
  basic: {
    speedSensitivity: 0.04,
    counterSteerStrength: 0.0,
    smoothingRate: 10.0,
    understeerRegain: 0.0,
    deadzone: 0.05,
  },
  advanced: {
    speedSensitivity: 0.05,
    counterSteerStrength: 0.85,
    smoothingRate: 15.0,
    understeerRegain: 0.1,
    deadzone: 0.08,
  },
  understeer: {
    speedSensitivity: 0.02,
    counterSteerStrength: 0.2,
    smoothingRate: 20.0,
    understeerRegain: 0.75,
    deadzone: 0.05,
  },
};

export default function App() {
  const [beamngScript, setBeamngScript] = useState<string>("");

  // Simulation States
  const [simulationActive, setSimulationActive] = useState<boolean>(true);
  const [simState, setSimState] = useState<SimState>({
    playerSteerInput: 0.0,
    calculatedSteerOutput: 0.0,
    speedKmh: 120,
    yawRate: 0.4,
    slipAngle: 0.22, // in radians (~13 deg) representing a drift
    isDrifting: true,
    isUndersteering: false,
    currentGForce: 1.2,
  });

  const [assistConfig, setAssistConfig] = useState<AssistConfig>(
    DEFAULT_CONFIGS.advanced,
  );
  const [downloading, setDownloading] = useState<boolean>(false);
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);

  // Custom templates mapped
  const [templates, setTemplates] = useState<any>(null);

  // Generate and Download the actual BeamNG Mod ZIP
  const handleDownloadMod = async () => {
    setDownloading(true);
    try {
      const zip = new JSZip();

      // 1. agaManager.lua (ge/extensions/auto)
      zip.file(
        "lua/ge/extensions/auto/agaManager.lua",
        `local M = {}
local function onVehicleSwitched(oldVehicleId, newVehicleId)
    local currVehicle = scenetree.findObject(newVehicleId)
    if currVehicle then
        currVehicle:queueLuaCommand('extensions.load("agaPhysics")')
    end
end
local function onVehicleSpawned(vid)
    local currVehicle = scenetree.findObject(vid)
    if currVehicle then
        currVehicle:queueLuaCommand('extensions.load("agaPhysics")')
    end
end
local function onInit()
    setExtensionUnloadMode(M, "manual")
end
M.onVehicleSwitched = onVehicleSwitched
M.onVehicleSpawned = onVehicleSpawned
M.onInit = onInit
return M
`,
      );

      // 1. mod_info.json (to ensure it registers as a valid mod)
      zip.file(
        "mod_info.json",
        JSON.stringify(
          {
            title: "Advanced Gamepad Assist UI & Physics",
            description: "Advanced gamepad steering, countersteer, and understeer physics with a tuning UI widget.",
            version: "1.0.0",
            author: "BeamNG Controller Fan",
            type: "mod"
          },
          null,
          2
        )
      );

      // 2. agaPhysics.lua (vehicle/extensions - auto load on spawn)
      zip.file("lua/vehicle/extensions/auto/agaPhysics.lua", beamngScript);

      // 3. UI App Files
      const uiDir = zip.folder("ui/modules/apps/agaTuning");

      // Transparent 1x1 PNG for app icon
      const transparentPngBase64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=";
      uiDir?.file("app.png", transparentPngBase64, { base64: true });

      uiDir?.file(
        "app.json",
        JSON.stringify(
          {
            name: "AGA Tuning",
            version: "1.0",
            description: "Advanced Gamepad Assist Tuning",
            author: "BeamNG",
            directive: "agaTuning",
            domElement: "<aga-tuning></aga-tuning>",
            css: {
               width: "280px",
               height: "320px",
               top: "20%",
               left: "5%"
            }
          },
          null,
          2,
        ),
      );

      uiDir?.file(
        "app.js",
        `angular.module('beamng.apps').directive('agaTuning', ['bngApi', function (bngApi) {
  return {
    template: '<div class="bngApp" style="width: 100%; height: 100%; background: rgba(20, 20, 20, 0.95); color: #fff; padding: 15px; border: 1px solid #ff6a00; box-sizing: border-box; font-family: \\'Roboto\\', sans-serif;">' +
                '<h2 style="margin: 0 0 10px 0; font-size: 16px; color: #ff6a00; border-bottom: 2px solid #ff6a00; padding-bottom: 5px; text-transform: uppercase;">AGA Tuning</h2>' +
                '<div style="margin-bottom: 12px;">' +
                  '<div style="display: flex; justify-content: space-between; margin-bottom: 4px; font-size: 13px;">' +
                    '<span>Speed Sensitivity</span>' +
                    '<span style="color: #ff6a00; font-weight: bold;">{{config.speed_sensitivity | number:3}}</span>' +
                  '</div>' +
                  '<input type="range" min="0" max="0.1" step="0.005" ng-model="config.speed_sensitivity" ng-change="updateConfig()" style="width: 100%;">' +
                '</div>' +
                '<div style="margin-bottom: 12px;">' +
                  '<div style="display: flex; justify-content: space-between; margin-bottom: 4px; font-size: 13px;">' +
                    '<span>Steer Filtering</span>' +
                    '<span style="color: #ff6a00; font-weight: bold;">{{config.max_steer_speed | number:1}}</span>' +
                  '</div>' +
                  '<input type="range" min="1" max="30" step="0.5" ng-model="config.max_steer_speed" ng-change="updateConfig()" style="width: 100%;">' +
                '</div>' +
                '<div style="margin-bottom: 12px;">' +
                  '<div style="display: flex; justify-content: space-between; margin-bottom: 4px; font-size: 13px;">' +
                    '<span>Countersteer</span>' +
                    '<span style="color: #ff6a00; font-weight: bold;">{{config.countersteer | number:2}}</span>' +
                  '</div>' +
                  '<input type="range" min="0" max="1.5" step="0.05" ng-model="config.countersteer" ng-change="updateConfig()" style="width: 100%;">' +
                '</div>' +
                '<div style="margin-bottom: 12px;">' +
                  '<div style="display: flex; justify-content: space-between; margin-bottom: 4px; font-size: 13px;">' +
                    '<span>Understeer Assist</span>' +
                    '<span style="color: #ff6a00; font-weight: bold;">{{config.understeer_assist | number:2}}</span>' +
                  '</div>' +
                  '<input type="range" min="0" max="1.0" step="0.05" ng-model="config.understeer_assist" ng-change="updateConfig()" style="width: 100%;">' +
                '</div>' +
              '</div>',
    replace: true,
    restrict: 'EA',
    link: function (scope, element, attrs) {
      scope.config = {
        speed_sensitivity: ${assistConfig.speedSensitivity !== undefined ? assistConfig.speedSensitivity : 0.05},
        max_steer_speed: ${assistConfig.smoothingRate !== undefined ? assistConfig.smoothingRate : 15.0},
        countersteer: ${assistConfig.counterSteerStrength !== undefined ? assistConfig.counterSteerStrength : 0.8},
        understeer_assist: ${assistConfig.understeerRegain !== undefined ? assistConfig.understeerRegain : 0.5}
      };

      scope.updateConfig = function() {
        var str = "speed_sensitivity=" + scope.config.speed_sensitivity + 
                  ",countersteer=" + scope.config.countersteer + 
                  ",max_steer_speed=" + scope.config.max_steer_speed + 
                  ",understeer_assist=" + scope.config.understeer_assist;
        var cmd = "if agaPhysics then agaPhysics.setConfig({" + str + "}) elseif extensions.agaPhysics then extensions.agaPhysics.setConfig({" + str + "}) end";
        bngApi.activeObjectLua(cmd);
      };

      scope.updateConfig();
    }
  };
}]);`
      );

      const blob = await zip.generateAsync({ type: "blob" });
      saveAs(blob, "aga_custom_assist.zip");
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 3000);
    } catch (error) {
      console.error("Failed to generate zip", error);
    } finally {
      setDownloading(false);
    }
  };

  // Fetch initial templates from the server on load
  useEffect(() => {
    async function fetchTemplates() {
      try {
        const response = await fetch("/api/templates");
        if (response.ok) {
          const data = await response.json();
          // Set initial code view to advanced model
          setBeamngScript(data.beamng.advanced);
        }
      } catch (e) {
        console.error("Templates loading error:", e);
      }
    }
    fetchTemplates();
  }, []);

  // Run the physics math loop for simulator in client-side dynamically
  useEffect(() => {
    if (!simulationActive) return;

    // Simulation calculation simulating AC / BeamNG gamepad helper state
    let targetOutput = 0;

    // 1. Speed Sensitivity Filter (Hız Hassasiyet Sınırlandırıcı)
    const kSpeed =
      1.0 / (1.0 + simState.speedKmh * assistConfig.speedSensitivity);
    const userLimitedSteer = simState.playerSteerInput * kSpeed;

    // 2. Counter-steer Calculation based on drift slip angle (Kontra-Yönlendirme Karşıt Kuvvet)
    let counterSteerAngle = 0;
    const absSlip = Math.abs(simState.slipAngle);

    // Only apply if slip angle is high, meaning a slide/drift is initiated
    if (absSlip > 0.1) {
      // Counter-steer targets the direction opposite value to realign vectors
      counterSteerAngle =
        -simState.slipAngle * assistConfig.counterSteerStrength;
    }

    // 3. Understeer Mitigation (Önden Kayma Azaltımı)
    let understeerCorrection = 1.0;
    const isSlippingFront =
      Math.abs(simState.playerSteerInput) > 0.5 &&
      simState.speedKmh > 70 &&
      absSlip < 0.15;
    if (isSlippingFront && assistConfig.understeerRegain > 0) {
      // Mitigate excessive steering scrub
      understeerCorrection = Math.max(
        0.4,
        1.0 - assistConfig.understeerRegain * 0.7,
      );
    }

    // Apply calculations
    targetOutput =
      (userLimitedSteer + counterSteerAngle) * understeerCorrection;

    // Clamp output in normal actuator limits [-1.0 to 1.0]
    targetOutput = Math.max(-1.0, Math.min(1.0, targetOutput));

    // Simple deadzone check
    if (Math.abs(simState.playerSteerInput) < assistConfig.deadzone) {
      targetOutput = counterSteerAngle; // only counter-steer acts on center stick during slides
      targetOutput = Math.max(-1.0, Math.min(1.0, targetOutput));
    }

    setSimState((prev) => ({
      ...prev,
      calculatedSteerOutput: targetOutput,
      isDrifting: absSlip > 0.15,
      isUndersteering: isSlippingFront,
      currentGForce:
        Math.abs(targetOutput) * (prev.speedKmh / 80) + prev.yawRate * 0.2,
    }));
  }, [
    simState.playerSteerInput,
    simState.speedKmh,
    simState.slipAngle,
    simState.yawRate,
    assistConfig,
    simulationActive,
  ]);

  return (
    <div
      id="app-root"
      className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col selection:bg-rose-500 selection:text-white"
    >
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-900/40 backdrop-blur-md sticky top-0 z-50 px-4 py-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div
              className="p-2.5 bg-rose-600/10 text-rose-500 border border-rose-500/20 rounded-xl shadow-inner shadow-rose-500/10"
              id="header-icon-container"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="28"
                height="28"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="animate-pulse"
              >
                <line x1="6" y1="12" x2="10" y2="12"></line>
                <line x1="8" y1="10" x2="8" y2="14"></line>
                <line x1="15" y1="13" x2="15.01" y2="13"></line>
                <line x1="18" y1="11" x2="18.01" y2="11"></line>
                <rect x="2" y="6" width="20" height="12" rx="2"></rect>
              </svg>
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-bold font-display tracking-tight text-white flex items-center gap-2">
                BeamNG.drive{" "}
                <span className="text-rose-500 font-light font-sans text-sm md:text-base border border-rose-500/30 bg-rose-950/40 px-2 py-0.5 rounded-full">
                  adam10603 / AC-Advanced-Gamepad-Assist Lab
                </span>
              </h1>
              <p className="text-xs text-slate-400">
                Entegre Edilen Mod: adam10603/AC-Advanced-Gamepad-Assist'in
                Gelişmiş CSP Algoritmalarının Portu
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1.5 text-xs bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-3 py-1.5 rounded-lg font-mono">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
              Modding Sandbox Aktif
            </span>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-[1400px] mx-auto w-full px-4 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Hand: BeamNG Architecture Plan (The Proposal) */}
        <section className="lg:col-span-8 flex flex-col gap-6">
          {/* AI Studio Confusion Alert */}
          <div className="bg-blue-950/40 border border-blue-500/30 rounded-2xl p-4 flex gap-4 shadow-xl mb-2 items-start">
            <AlertCircle className="w-6 h-6 text-blue-400 shrink-0 mt-0.5" />
            <div>
              <h3 className="text-sm font-bold text-white mb-1">
                AI Studio Export'u Hakkında Not
              </h3>
              <p className="text-xs text-blue-200 leading-relaxed">
                Platformun üstündeki "Export" tuşuna bastıysanız, 38kb'lık bu{" "}
                <strong>web uygulamasının kaynak kodlarını (React)</strong>{" "}
                indirmiş olursunuz. Gerçek BeamNG modunu (Lua ve UI klasörleri
                içeren çalıştırılabilir hali) oluşturmak için aşağıdaki
                bölümdeki <strong>"Modu Zip Olarak İndir"</strong> butonunu
                kullanmalısınız.
              </p>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-rose-500/10 rounded-full blur-3xl pointer-events-none"></div>

            <h2 className="text-2xl font-display font-bold text-white mb-6">
              AGA Global Entegrasyon Planı{" "}
              <span className="text-sm font-medium text-slate-400 font-sans ml-2">
                BeamNG.drive Mod Mimari Teklifi
              </span>
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-slate-950/80 p-4 rounded-xl border border-rose-500/20 shadow-inner">
                <div className="w-8 h-8 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center mb-3">
                  1
                </div>
                <h4 className="font-bold text-white mb-1">Global Manager</h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  <code className="text-emerald-400">ge/extensions/</code>{" "}
                  katmanında çalışır. Araç değiştirildiğinde veya spawn
                  edildiğinde fiziği o araca otomatik enjekte eder. Tek tek
                  kurma derdi biter.
                </p>
              </div>
              <div className="bg-slate-950/80 p-4 rounded-xl border border-emerald-500/20 shadow-inner">
                <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-3">
                  2
                </div>
                <h4 className="font-bold text-white mb-1">Physics Engine</h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  <code className="text-emerald-400">vehicle/extensions/</code>{" "}
                  katmanında. Adam10603 algoritmalarının kalbi, sadece aktif
                  araçta saniyede 2000Hz hızında pürüzsüzce çalışır.
                </p>
              </div>
              <div className="bg-slate-950/80 p-4 rounded-xl border border-amber-500/20 shadow-inner">
                <div className="w-8 h-8 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center mb-3">
                  3
                </div>
                <h4 className="font-bold text-white mb-1">In-Game UI App</h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Oyun içi UI editörden açılabilen temiz arayüz. Yaptığın
                  ayarları anında (real-time) AC Physics motoruna iletir.
                </p>
              </div>
            </div>

            <h3 className="text-sm font-bold text-slate-300 uppercase tracking-widest mb-3">
              Geliştirilecek Kod Çıktısı (Önizleme)
            </h3>
            <div className="bg-slate-950 rounded-xl overflow-hidden border border-slate-800">
              <div className="flex bg-slate-900 border-b border-slate-800">
                <div className="px-4 py-2 border-r border-slate-800 text-xs font-mono text-white bg-slate-800/50">
                  agaManager.lua
                </div>
                <div className="px-4 py-2 border-r border-slate-800 text-xs font-mono text-emerald-400">
                  agaPhysics.lua
                </div>
                <div className="px-4 py-2 border-r border-slate-800 text-xs font-mono text-slate-400 hover:text-white cursor-pointer transition-colors block">
                  app.html / js
                </div>
              </div>
              <textarea
                value={beamngScript}
                readOnly
                className="w-full p-4 bg-transparent text-slate-300 font-mono text-xs h-[320px] focus:outline-none resize-none leading-relaxed"
              />
            </div>

            <div className="mt-6 flex flex-col md:flex-row items-center justify-between bg-slate-950 p-4 rounded-xl border border-rose-500/30 gap-4">
              <div className="text-xs text-slate-400">
                <span className="text-white font-bold block mb-1">
                  Modu Derle ve İndir
                </span>
                Lua ve UI kodları klasörlenip tek zip haline getirilecektir.
              </div>
              <button
                onClick={handleDownloadMod}
                disabled={downloading || !beamngScript}
                className="w-full md:w-auto bg-rose-600 hover:bg-rose-500 active:bg-rose-700 disabled:opacity-50 text-white font-semibold text-sm px-6 py-3 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-rose-950/20"
              >
                {downloadSuccess ? (
                  <>
                    <CheckCircle2 className="w-5 h-5 text-green-300" /> Mod
                    İndirildi!
                  </>
                ) : downloading ? (
                  <span>Oluşturuluyor...</span>
                ) : (
                  <>
                    <FileArchive className="w-5 h-5" />
                    BeamNG Modu Olarak İndir (.zip)
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Canlı Simülasyon Verisi */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex items-center justify-between">
            <div>
              <h3 className="text-lg font-bold text-white mb-1">
                Canlı Fizik Simülasyonu
              </h3>
              <p className="text-xs text-slate-400">
                Yandaki UI penceresini denemek için aşağıdaki değişkenlerle
                oyna.
              </p>
            </div>
            <div className="flex gap-4">
              <div className="bg-slate-950 px-4 py-2 rounded-lg border border-slate-800 text-center">
                <div className="text-[10px] text-slate-500">SPEED</div>
                <input
                  type="range"
                  min="0"
                  max="250"
                  value={simState.speedKmh}
                  onChange={(e) =>
                    setSimState((prev) => ({
                      ...prev,
                      speedKmh: parseInt(e.target.value),
                    }))
                  }
                  className="w-24 mt-1"
                />
              </div>
              <div className="bg-slate-950 px-4 py-2 rounded-lg border border-slate-800 text-center">
                <div className="text-[10px] text-slate-500">SLIP ANGLE</div>
                <input
                  type="range"
                  min="-0.8"
                  max="0.8"
                  step="0.02"
                  value={simState.slipAngle}
                  onChange={(e) =>
                    setSimState((prev) => ({
                      ...prev,
                      slipAngle: parseFloat(e.target.value),
                    }))
                  }
                  className="w-24 mt-1 accent-amber-500"
                />
              </div>
              <div className="bg-slate-950 px-4 py-2 rounded-lg border border-slate-800 text-center">
                <div className="text-[10px] text-slate-500">STICK INPUT</div>
                <input
                  type="range"
                  min="-1"
                  max="1"
                  step="0.01"
                  value={simState.playerSteerInput}
                  onChange={(e) =>
                    setSimState((prev) => ({
                      ...prev,
                      playerSteerInput: parseFloat(e.target.value),
                    }))
                  }
                  className="w-24 mt-1 accent-rose-500"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Right Hand: ImGui Style In-Game UI App Prototype */}
        <section className="lg:col-span-4 flex justify-center items-start pt-4">
          {/* ImGui-style window wrapper */}
          <div className="w-[340px] bg-[#1a1a1a] border border-[#333333] rounded shadow-2xl overflow-hidden font-sans select-none relative group transition-all">
            {/* ImGui Title Bar */}
            <div className="bg-[#2d2d2d] border-b border-[#111111] px-3 py-1.5 flex justify-between items-center text-xs cursor-move">
              <span className="font-semibold text-[#e0e0e0]">
                Advanced Gamepad Assist (BeamNG)
              </span>
              <div className="flex gap-1.5">
                <div className="w-2.5 h-2.5 rounded-sm bg-[#555] hover:bg-rose-500 cursor-pointer"></div>
              </div>
            </div>

            {/* Application Content */}
            <div className="p-3 bg-[#1e1e1e] text-[#cccccc] space-y-4">
              {/* Steer Gamma */}
              <div className="space-y-1 group/slider">
                <div className="flex justify-between text-[11px] px-1">
                  <span className="text-[#999999]">Steer Gamma</span>
                  <span className="font-mono text-emerald-400">1.60</span>
                </div>
                <div className="relative h-4 bg-[#111111] rounded-sm ring-1 ring-[#333] hover:ring-emerald-500/50 cursor-pointer overflow-hidden flex items-center px-1">
                  <div className="absolute top-0 bottom-0 left-0 bg-[#3a4740] w-[30%]"></div>
                  <span className="relative text-[10px] z-10 w-full text-center mix-blend-screen text-white/50">
                    1.60x
                  </span>
                </div>
              </div>

              {/* Filtering / Steer Speed */}
              <div className="space-y-1 group/slider">
                <div className="flex justify-between text-[11px] px-1">
                  <span className="text-[#999999]">Steer Rate Filter</span>
                  <span className="font-mono text-emerald-400">
                    {assistConfig.smoothingRate.toFixed(1)}
                  </span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="30"
                  step="0.5"
                  value={assistConfig.smoothingRate}
                  onChange={(e) =>
                    setAssistConfig((p) => ({
                      ...p,
                      smoothingRate: parseFloat(e.target.value),
                    }))
                  }
                  className="w-full h-3 appearance-none rounded-sm bg-[#111111] ring-1 ring-[#333] [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:bg-[#666] [&::-webkit-slider-thumb]:rounded-sm"
                />
              </div>

              {/* Speed Sensitivity */}
              <div className="space-y-1 group/slider">
                <div className="flex justify-between text-[11px] px-1">
                  <span className="text-[#999999]">Speed Sensitivity</span>
                  <span className="font-mono text-emerald-400">
                    {assistConfig.speedSensitivity.toFixed(3)}
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="0.1"
                  step="0.005"
                  value={assistConfig.speedSensitivity}
                  onChange={(e) =>
                    setAssistConfig((p) => ({
                      ...p,
                      speedSensitivity: parseFloat(e.target.value),
                    }))
                  }
                  className="w-full h-3 appearance-none rounded-sm bg-[#111111] ring-1 ring-[#333] [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:bg-[#666] [&::-webkit-slider-thumb]:rounded-sm"
                />
              </div>

              {/* Countersteer Assist */}
              <div className="space-y-1 group/slider">
                <div className="flex justify-between text-[11px] px-1">
                  <span className="text-[#999999]">Countersteer Assist</span>
                  <span className="font-mono text-emerald-400">
                    {(assistConfig.counterSteerStrength * 100).toFixed(0)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1.5"
                  step="0.05"
                  value={assistConfig.counterSteerStrength}
                  onChange={(e) =>
                    setAssistConfig((p) => ({
                      ...p,
                      counterSteerStrength: parseFloat(e.target.value),
                    }))
                  }
                  className="w-full h-3 appearance-none rounded-sm bg-[#111111] ring-1 ring-[#333] [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:bg-[#666] [&::-webkit-slider-thumb]:rounded-sm"
                />
              </div>

              <div className="border-t border-[#333] pt-3 mt-4">
                <label className="flex items-center gap-2 cursor-pointer group/check">
                  <div className="w-4 h-4 bg-[#111111] ring-1 ring-[#333] rounded-xs flex items-center justify-center group-hover/check:ring-[#555]">
                    <div className="w-2 h-2 bg-emerald-500 rounded-sm"></div>
                  </div>
                  <span className="text-[11px] text-[#999]">
                    Enable Dynamic Slip Prediction
                  </span>
                </label>
              </div>
            </div>

            {/* Live Telemetry Output (Bottom Bar of Window) */}
            <div className="bg-[#111111] px-3 py-2 border-t border-[#333] mt-2 font-mono flex flex-col gap-1.5">
              <div className="flex justify-between text-[10px]">
                <span className="text-[#666]">ACTUAL W. ANGLE</span>
                <span
                  className={
                    Math.abs(simState.calculatedSteerOutput) > 0.05
                      ? "text-amber-400"
                      : "text-[#888]"
                  }
                >
                  {(simState.calculatedSteerOutput * 100).toFixed(1)}%
                </span>
              </div>

              {/* Steer Output Bar */}
              <div className="h-1.5 bg-[#222] rounded-full relative overflow-hidden">
                <div
                  className="absolute top-0 bottom-0 bg-emerald-500/80 transition-all"
                  style={{
                    left:
                      simState.calculatedSteerOutput >= 0
                        ? "50%"
                        : `calc(50% - ${Math.abs(simState.calculatedSteerOutput) * 50}%)`,
                    right:
                      simState.calculatedSteerOutput >= 0
                        ? `calc(50% - ${simState.calculatedSteerOutput * 50}%)`
                        : "50%",
                  }}
                ></div>
                <div className="absolute top-0 bottom-0 left-1/2 w-[1px] bg-[#666] -translate-x-1/2"></div>
              </div>

              <div className="flex justify-between text-[9px] text-[#555] mt-1">
                <span>SIM_SPEED: {simState.speedKmh}KMH</span>
                <span>
                  STATE: {simState.isDrifting ? "SLIDE_CORRECTING" : "GRIP"}
                </span>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 px-4 mt-12 text-center text-xs text-slate-500 font-mono">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>
            © 2026 Gamepad Assist Modding Lab for BeamNG.drive and Assetto Corsa
          </p>
          <div className="flex gap-4">
            <a
              href="https://documentation.beamng.com"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-rose-400 transition-colors"
            >
              BeamNG API Belgelendirmesi
            </a>
            <span>•</span>
            <span className="text-slate-400">Lua Framework 5.3</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

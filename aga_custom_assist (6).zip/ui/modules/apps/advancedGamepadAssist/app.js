angular.module('beamng.apps').directive('advancedGamepadAssist', ['bngApi', function (bngApi) {
  return {
    template: `<div class="bngApp" style="width: 100%; height: 100%; background: rgba(20,20,20,0.95); color: #fff; padding: 15px; font-family: Roboto, sans-serif; border: 1px solid #ef6a00; border-radius: 5px; box-sizing: border-box; overflow-y: auto;">
      <h3 style="margin-top: 0; color: #ef6a00; border-bottom: 2px solid #ef6a00; padding-bottom: 8px; font-size: 14px; text-transform: uppercase;">AGA Tuning</h3>
      
      <div style="margin-top: 15px; font-size: 12px;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 4px;"><span>Speed Sensitivity</span><span style="color: #ef6a00; font-weight: bold;">{{config.speedSensitivity | number:3}}</span></div>
        <input type="range" min="0" max="0.1" step="0.005" ng-model="config.speedSensitivity" ng-change="updateSettings()" style="width: 100%; accent-color: #ef6a00;">
      </div>

      <div style="margin-top: 15px; font-size: 12px;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 4px;"><span>Steer Filtering</span><span style="color: #ef6a00; font-weight: bold;">{{config.smoothingRate | number:1}}</span></div>
        <input type="range" min="1" max="30" step="0.5" ng-model="config.smoothingRate" ng-change="updateSettings()" style="width: 100%; accent-color: #ef6a00;">
      </div>

      <div style="margin-top: 15px; font-size: 12px;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 4px;"><span>Countersteer Assist</span><span style="color: #ef6a00; font-weight: bold;">{{config.counterSteerStrength | number:2}}</span></div>
        <input type="range" min="0" max="1.5" step="0.05" ng-model="config.counterSteerStrength" ng-change="updateSettings()" style="width: 100%; accent-color: #ef6a00;">
      </div>
      
      <div style="margin-top: 15px; font-size: 12px;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 4px;"><span>Understeer Assist</span><span style="color: #ef6a00; font-weight: bold;">{{config.understeerAssist | number:2}}</span></div>
        <input type="range" min="0" max="1.0" step="0.05" ng-model="config.understeerAssist" ng-change="updateSettings()" style="width: 100%; accent-color: #ef6a00;">
      </div>
    </div>`,
    replace: true,
    restrict: 'EA',
    link: function (scope, element, attrs) {
      scope.config = {
        speedSensitivity: 0.05,
        smoothingRate: 15,
        counterSteerStrength: 0.85,
        understeerAssist: 0.1
      };
      
      var lastUpdate = 0;
      scope.updateSettings = function() {
        var now = Date.now();
        if (now - lastUpdate > 50) {
          var luaCode = "if extensions.agaPhysics then extensions.agaPhysics.setConfig({speed_sensitivity=" + scope.config.speedSensitivity + ", countersteer=" + scope.config.counterSteerStrength + ", max_steer_speed=" + scope.config.smoothingRate + ", understeer_assist=" + scope.config.understeerAssist + "}) end";
          bngApi.activeObjectLua(luaCode);
          lastUpdate = now;
        }
      };
      
      scope.updateSettings();
    }
  };
}]);

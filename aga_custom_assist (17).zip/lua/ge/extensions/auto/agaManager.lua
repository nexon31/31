local M = {}
local activeVehicleId = nil

local function loadAgaPhysics(vehicleId)
    if not vehicleId then return end
    local currVehicle = be:getObjectByID(vehicleId) or (scenetree and scenetree.findObject and scenetree.findObject(vehicleId))
    if currVehicle then
        currVehicle:queueLuaCommand('extensions.load("agaPhysics")')
    end
end

local function onVehicleSwitched(oldVehicleId, newVehicleId)
    activeVehicleId = newVehicleId
    loadAgaPhysics(newVehicleId)
end

local function onVehicleSpawned(vid)
    loadAgaPhysics(vid)
end

local function onUpdate()
    if be and be.getPlayerVehicleID then
        local vehicleId = be:getPlayerVehicleID(0)
        if vehicleId and vehicleId ~= activeVehicleId then
            activeVehicleId = vehicleId
            loadAgaPhysics(vehicleId)
        end
    end
end

local function onInit()
    if setExtensionUnloadMode then
        setExtensionUnloadMode(M, "manual")
    end
end

M.onVehicleSwitched = onVehicleSwitched
M.onVehicleSpawned = onVehicleSpawned
M.onUpdate = onUpdate
M.onInit = onInit
return M

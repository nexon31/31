var app = angular.module('beamng.apps');

function createDirective(bngApi) {
  return {
    templateUrl: '/ui/modules/apps/advancedGamepadAssist/app.html',
    replace: true,
    restrict: 'EA',
    link: function (scope, element, attrs) {
      scope.config = {
        speed_sensitivity: 0.05,
        max_steer_speed: 15,
        countersteer: 0.85,
        understeer_assist: 0.1
      };

      scope.updateConfig = function () {
        var sens = parseFloat(scope.config.speed_sensitivity) || 0.05;
        var steer = parseFloat(scope.config.max_steer_speed) || 15.0;
        var counter = parseFloat(scope.config.countersteer) || 0.8;
        var under = parseFloat(scope.config.understeer_assist) || 0.5;

        var str = "speed_sensitivity=" + sens +
                  ",countersteer=" + counter +
                  ",max_steer_speed=" + steer +
                  ",understeer_assist=" + under;

        // Channel 1: Active vehicle object LUA context
        var cmd = "extensions.load('agaPhysics'); if agaPhysics then agaPhysics.setConfig({" + str + "}) elseif extensions.agaPhysics then extensions.agaPhysics.setConfig({" + str + "}) end";
        bngApi.activeObjectLua(cmd);

        // Channel 2: Game Engine player vehicle LUA fallback trigger
        var geCmd = "local v = be:getPlayerVehicle(0); if v then v:queueLuaCommand(\"extensions.load('agaPhysics'); if agaPhysics then agaPhysics.setConfig({" + str + "}) elseif extensions.agaPhysics then extensions.agaPhysics.setConfig({" + str + "}) end\") end";
        bngApi.engineLua(geCmd);
      };

      scope.$on('VehicleReset', function () {
        scope.updateConfig();
      });

      scope.$on('VehicleChange', function () {
        scope.updateConfig();
      });

      scope.updateConfig();
    }
  };
}

// Map multiple angular directives to prevent any lowercase/camelCase element resolution mismatch in different BeamNG releases
app.directive('advancedGamepadAssist', ['bngApi', createDirective]);
app.directive('advancedgamepadassist', ['bngApi', createDirective]);
app.directive('agaTuning', ['bngApi', createDirective]);
app.directive('agatuning', ['bngApi', createDirective]);
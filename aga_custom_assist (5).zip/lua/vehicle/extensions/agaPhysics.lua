-- lua/vehicle/extensions/agaPhysics.lua
local M = {}

M.config = {
    speed_sensitivity = 0.05,
    exp_gamma = 1.6,
    countersteer = 0.85,
    max_steer_speed = 15.0,
    understeer_assist = 0.5
}

local current_steering = 0
local function updateGFX(dt)
    -- Vektör Matematiği ve Hız Hesaplama
    local vel = obj:getVelocity() -- Yönü ve büyüklüğü ile birlikte aracın hızı
    local dir = obj:getDirectionVector() -- Aracın burnunun baktığı vektör
    local dirUp = obj:getDirectionVectorUp() -- Aracın üst yönü
    
    -- Aracın sağına/soluna olan yön vektörü (Cross Product kullanarak hesaplanır, getDirectionVectorRight YOKTUR!)
    local dirRight = dir:cross(dirUp)
    
    -- İleri/Geri (vx) ve Yanal (vy) hızları Dot Product ile hesapla (m/s)
    local vx = vel:dot(dir)
    local vy = vel:dot(dirRight)

    local speed_kmh = math.abs(vx) * 3.6
    
    -- Ham direksiyon verisini al (BeamNG'de electrics.values.steering_input kullanılır)
    local raw_steer = electrics.values.steering_input or 0
    
    -- Gamma (Hassasiyet eğrisi)
    local stick_sign = raw_steer >= 0 and 1 or -1
    local soft_input = stick_sign * (math.abs(raw_steer) ^ M.config.exp_gamma)
    
    -- Speed Limit (Hıza duyarlı maksimum direksiyon açısını daralt)
    local limit_factor = 1.0 / (1.0 + speed_kmh * M.config.speed_sensitivity)
    local target = soft_input * limit_factor
    
    -- Slide Angle & Countersteer
    local slip_angle = 0
    if math.abs(vx) > 2.0 then
        slip_angle = math.atan2(vy, math.abs(vx))
    end
    
    if math.abs(slip_angle) > 0.05 then
        target = target - (slip_angle * M.config.countersteer)
    end
    
    -- Understeer Assist (Önden Kayma Kurtarıcısı)
    local understeer_correction = 1.0
    -- Eğer hız yüksekse, oyuncu direksiyonu çok çeviriyorsa ama araç kaymıyorsa (kafadan açarak gidiyorsa)
    if speed_kmh > 40 and math.abs(raw_steer) > 0.4 and math.abs(slip_angle) < 0.1 then
        understeer_correction = math.max(0.3, 1.0 - M.config.understeer_assist)
    end
    target = target * understeer_correction
    
    -- Sınırlayıcı ve Uygulayıcı (Zamanla yumuşatma)
    target = math.max(-1.0, math.min(1.0, target))
    local steer_error = target - current_steering
    current_steering = current_steering + steer_error * math.min(1.0, dt * M.config.max_steer_speed)
    
    -- İşlenmiş asistanlı direksiyon çıktısını doğrudan hidroliklere bas. (input.event araç içinde çalışmaz)
    electrics.values.steering = current_steering
end

local function setConfig(cfg)
    if cfg.speed_sensitivity then M.config.speed_sensitivity = cfg.speed_sensitivity end
    if cfg.countersteer then M.config.countersteer = cfg.countersteer end
    if cfg.max_steer_speed then M.config.max_steer_speed = cfg.max_steer_speed end
    if cfg.understeer_assist then M.config.understeer_assist = cfg.understeer_assist end
    if cfg.exp_gamma then M.config.exp_gamma = cfg.exp_gamma end
end

M.updateGFX = updateGFX
M.setConfig = setConfig
return M